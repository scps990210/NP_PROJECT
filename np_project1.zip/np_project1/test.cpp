#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <string>
#include <unistd.h>
#include <sys/wait.h>
#include <sstream>
#include <vector>
#include <fcntl.h>
#include <sys/stat.h>

using namespace std;


int main(){
    setenv("PATH","bin:.",1);
	while(1){
		string input;
		cout << "% ";
		getline(cin,input);
        char del_c = ' ';

        //Check built in
        istringstream is(input);
	    string str;
	    getline(is,str,del_c);
	    if(str == "printenv"){
		    getline(is,str,del_c);
            char *val = getenv(str.c_str());
	        if(val) cout << val << endl;
	    }else if(str == "setenv"){
		    string name,val;
		    getline(is,name,del_c);
		    getline(is,val,del_c);
            setenv(name.c_str(),val.c_str(),1);
	    }else if(str == "exit"){
		    exit(0);
	    }

        //Split | character
	    vector<string> cmds;
	    string del = " | ";
	    size_t pos = 0;
	    //int k = 0;
	    while((pos = input.find(del)) != string::npos){
		    cmds.push_back(input.substr(0,pos));
		    //cout << "cmds = " << cmds[k++] << endl;
		    input.erase(0,pos + del.length());
		    //cout << "input = " << input << endl;
	    }
        
	}	
	return 0;
}